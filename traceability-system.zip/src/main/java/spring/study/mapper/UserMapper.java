package spring.study.mapper;

public interface UserMapper {
}
