package spring.study.dto;

import lombok.Data;

@Data
public class ArtifactDTO {
    private String description;
    private String type;
}